# _*_ coding: utf-8 _*_
from oopzchool.school import (Student,Tesla,SpecialStudent,Teacher)
from oopzchool.newschool import Test