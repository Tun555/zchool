# # _*_ coding: utf-8 _*_
import oopzchool.school
from oopzchool.school import Student,SpecialStudent
from oopzchool.school import *

def Test():
    """    
    This is example that build by this packate
    st1 = school.Student('Albert','Einstein')
    print(st1)

    st2 = Student("Bill","Gates")
    print(st2)

    stp1 = SpecialStudent('T','E','P')
    teacher1 = Teacher('Ada')
    print(teacher1.fullname)
    """
    st1 = school.Student('Albert','Einstein')
    print(st1)

    st2 = Student("Bill","Gates")
    print(st2)

    stp1 = SpecialStudent('T','E','P')
    teacher1 = Teacher('Ada')
    print(teacher1.fullname)



print(help(Test))

